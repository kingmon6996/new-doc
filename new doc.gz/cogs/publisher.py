from discord.ext import commands
import discord
import db

difficulty = {'⭐' : 0x2d9e00, '⭐⭐' : 0xe6cf00, '⭐⭐⭐' : 0xcf7f00, '⭐⭐⭐⭐' : 0xcf0000 }

class Publisher(commands.Cog):
    def __init__(self, client : commands.Bot):
        self.client = client
        self.db = db.DataBase()
    
    @commands.Cog.listener()
    async def on_message(self, msg: discord.Message):
        if msg.author.id == 669228505128501258 and msg.embeds:
            if msg.embeds[0].title and 'Raid Announcement' in msg.embeds[0].title:
                embed = msg.embeds[0].copy()
                stars = embed.description.split(' ')[-16].replace('\n', '')
                time = embed.description.split(' ')[9].replace('\n', '')
                if time == '15':
                    data = await self.db.get_guild_data(guild=msg.guild.id)
                    if data:
                        channel = data['channel']
                        invite = data['invite']
                        channel_id = await self.db.get_channel_by_difficulty(stars=stars)
                        ch = self.client.get_channel(int(channel_id))
                        embed.description = f'{embed.description}\n\n**Server Name = **{msg.guild.name}\n**Channel = **<#{channel}>\n**Invite = **[Invite]({invite})'
                        embed.color = difficulty[f'{stars}']
                        await ch.send(embed=embed)
    
    @commands.command(name='add')
    @commands.has_permissions(manage_channels=True)
    async def add(self, ctx: commands.Context, channel: discord.TextChannel, invite: str):
        await self.db.add_data(guild=ctx.guild.id, channel=channel.id, invite=invite)
        await ctx.reply(f'Added {channel.mention} in database.')

async def setup(client):
    await client.add_cog(Publisher(client))