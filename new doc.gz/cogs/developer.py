from discord.ext import commands
from glob import glob as getfiles
import discord

em_color = 0xf55656

def filenames() -> list:
    cogs = [i.split('/')[-1].replace('.py', '') for i in getfiles("cogs/*.py")]
    return cogs

devs = [730998447439609856]

class DevCommands(commands.Cog):
    def __init__(self, client : commands.Bot):
        self.client = client
    

    @commands.command(name='cogs')
    async def cogs(self, ctx):   
        if ctx.author.id not in devs: return         
        files = filenames()
        cogs = discord.Embed(title='List Of Cogs', description='\n'.join(files), color=em_color)
        await ctx.channel.send(embed=cogs)
    @cogs.error
    async def cogs_error(self ,ctx, error):
        await ctx.reply(str(error))


    @commands.command(name='ping')
    async def ping(self, ctx):
        if ctx.author.id not in devs: return         
        await ctx.channel.send(content = f'{round(self.client.latency*1000, 1)}ms')
    @ping.error
    async def ping_error(self ,ctx, error):
        await ctx.reply(str(error))

    
    @commands.command(name='load')
    async def load(self, ctx, cog: str):
        if ctx.author.id not in devs: return
        if cog == 'all':
            for i in filenames():
                await self.client.load_extension('cogs.{}'.format(i.lower()))
                message = f'Added all cogs'
        else:
            await self.client.load_extension('cogs.{}'.format(cog.lower()))
            message = f'Added {cog}'
        await ctx.channel.send(message)
    @load.error
    async def load_error(self ,ctx, error):
        await ctx.reply(str(error))


    @commands.command(name='unload')
    async def unload(self, ctx, cog: str):
        if ctx.author.id not in devs: return
        await self.client.unload_extension('cogs.{}'.format(cog.lower()))
        message = f'Removes {cog}'
        await ctx.channel.send(message)
    @unload.error
    async def unload_error(self ,ctx, error):
        await ctx.reply(str(error))


    @commands.command(name='reload')
    async def reload(self, ctx, cog: str):
        if ctx.author.id not in devs: return
        await self.client.reload_extension('cogs.{}'.format(cog.lower()))
        message = f'Reloaded {cog}'
        await ctx.channel.send(message)
    @reload.error
    async def reload_error(self ,ctx, error):
        await ctx.reply(str(error))


    @commands.command(name='sync')
    async def sync(self, ctx):
        if ctx.author.id not in devs: return
        await self.client.tree.sync()
        message = 'successfully synced'
        await ctx.channel.send(message)
    @sync.error
    async def sync_error(self ,ctx, error):
        await ctx.reply(str(error))



async def setup(client):
    await client.add_cog(DevCommands(client))