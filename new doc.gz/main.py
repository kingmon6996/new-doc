import discord
import datetime
from discord.ext import commands, tasks


intents = discord.Intents.default()
intents.message_content = True
client = commands.Bot(command_prefix=commands.when_mentioned_or('r.'), case_insensitive=True, intents=intents)


@client.event
async def on_ready():
    await client.load_extension('cogs.developer')
    await client.load_extension('cogs.publisher')
    print(f'Logged in as {client.user}.')

@client.event
async def on_message(msg: discord.Message):
    await client.process_commands(msg)

@client.command(name='developer')
async def dev(ctx):
    try: 
        await client.load_extension('developer')
        message = f'Developer commands successfully loaded'
    except:
        await client.reload_extension('developer')
        message = f'Developer commands successfully reloaded'
    await ctx.channel.send(message)
@dev.error
async def load_error(ctx, error):
    await ctx.reply(str(error))

client.run(token='MTI2MzEwNDIyNTQxMjM4NjgxNg.GNc4ub.Kup2Ths6ywn58iRzTLam_iF_gY0p4IiGFF4oho')