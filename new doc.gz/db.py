import ujson as json

class DataBase:
    def __init__(self) -> None:
        self.file = 'data/channel.json'

    async def read(self) -> dict[dict]:
        with open(self.file, 'r') as f: data = json.loads(f.read())
        return data
    
    async def save(self, data: dict[dict]) -> None:
        with open(self.file, 'w') as f: f.write(json.dumps(data, indent=4))

    async def add_data(self, guild: str|int , channel: str|int, invite: str|int) -> None:
        data = await self.read()
        data[f'{guild}'] = {'channel' : f'{channel}',
                            'invite' : f'{invite}'}
        
        await self.save(data=data)
    
    async def get_guild_data(self, guild: str|int) -> dict[dict] | None:
        data = await self.read()
        guild_data = data.get(f'{guild}')
        return guild_data

    async def get_channel_by_difficulty(self, stars: str) -> int:
        with open('data/difficulty.json', 'r', encoding='utf-8') as f:
            category: dict = json.loads(f.read())
        return category.get(stars)